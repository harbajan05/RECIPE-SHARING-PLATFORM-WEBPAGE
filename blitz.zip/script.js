const recipeList = document.querySelector('#recipe-list');
const noRecipes = document.getElementById('no-recipes');
function displayRecipes() {
    recipeList.innerHTML = '';
    recipes.forEach((recipe, index) => {
      const recipeDiv = document.createElement('div');
    });
  }
  
const form = document.querySelector('form');
let recipes = [];
function handleSubmit(event) {
    // Prevent default form submission behavior
    event.preventDefault();
    
    // Get recipe name, ingredients, and method input values
    const nameInput = document.querySelector('#recipe-name');
    const ingrInput = document.querySelector('#recipe-ingredients');
    const methodInput = document.querySelector('#recipe-method');
    const name = nameInput.value.trim();
    const ingredients = ingrInput.value.trim().split(',').map(i => i.trim());
    const method = methodInput.value.trim();
    if (name && ingredients.length > 0 && method) {
        const newRecipe = { name, ingredients, method };
        recipes.push(newRecipe);
      }
      nameInput.value = '';
ingrInput.value = '';
methodInput.value = '';
form.addEventListener('submit', handleSubmit);
  }
  recipeDiv.classList.add('recipe');
  recipeList.appendChild(recipeDiv);
  noRecipes.style.display = recipes.length > 0 ? 'none' : 'flex';
  displayRecipes();
  searchBox.addEventListener('input', event => search(event.target.value));
  searchBox.value = '';
  function handleDelete(event) {

  if (event.target.classList.contains('delete-button')) {
    const index = event.target.dataset.index;
  }
  recipes.splice(index, 1);
  recipeList.addEventListener('click', handleDelete);
  const searchBox = document.getElementById('search-box');
  function search(query) {
    const filteredRecipes = recipes.filter(recipe => {
      return recipe.name.toLowerCase().includes(query.toLowerCase());
    });
  }
  window.alert("saved");
}
